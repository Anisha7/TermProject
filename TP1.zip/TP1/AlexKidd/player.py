# player set up
import pygame
from pygame.locals import *
from pygamegame import *

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super(Player, self).__init__()
        self.surf = pygame.Surface((75, 25))
        self.surf.fill((200, 155, 255))
        self.x = x//2
        self.y = y - y//4
        self.rect = self.surf.get_rect()
        self.lives = 3
        self.score = 0
        self.level = 1

    def update(self, pressed_keys):
        dist = 5

        if pressed_keys[K_UP]:
            self.y -= dist
        if pressed_keys[K_DOWN]:
            self.y += dist
        if pressed_keys[K_LEFT]:
            self.x -= dist
        if pressed_keys[K_RIGHT]:
            self.x += dist

    def draw(self, surface):
        surface.blit(self.surf, (self.x, self.y))

class Punches(pygame.sprite.Sprite):
    def __init__(self):
        pass
        # create a group of boomeranges that are shot when punch activated

    def checkCollision(self, enemyx, enemyy):
        if self.x == enemyx and self.y == enemyy:
            pass

        pass
